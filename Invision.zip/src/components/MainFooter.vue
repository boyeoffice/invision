<template>
	<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.3.6
    </div>
    <strong>Copyright © 2014-2016 <a href="#">Invision</a>.</strong> All rights
    reserved.
  </footer>
</template>