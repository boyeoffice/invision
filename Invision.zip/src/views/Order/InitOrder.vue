<template lang="html">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          Order Transaction - Ron Weasley - 2017 Winter Session
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-md-4">
              Ordered on June 8, 2017
            </div>
            <div class="col-md-4">
              Transaction Type: Purchase
            </div>
            <div class="col-md-4">
              <span>Ordered Id: t859esd8r8947y4676w8u09</span>
              <br/>
              <span>Stripe Tx ID: ccx-xxx--sss-eee-ffff</span>
            </div>
          </div>
          <!-- /.row -->
          <div class="row">
            <div class="col-md-4">
              <b>Payment Details</b>
            </div>
            <div class="col-md-6">
              American Express xxxxxxxxxxxxxx19
            </div>
          </div>
          <!-- /.row -->
          <div class="row">
            <div class="col-md-12">
              <label for="monday">Monday</label>
              <table class="table table-stripped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Days</th>
                    <th>Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="col-md-4">Froozen Butterbeer</td>
    								<td class="col-md-2">$2.00</td>
    								<td class="col-md-2">1</td>
                    <td class="col-md-2">16</td>
                    <td class="col-md-2">$32.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /.row -->
          <div class="row">
            <div class="col-md-12">
              <label for="monday">Monday</label>
              <table class="table table-stripped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Days</th>
                    <th>Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Froozen Butterbeer</td>
                    <td>$2.00</td>
                    <td>1</td>
                    <td>16</td>
                    <td>$32.00</td>
                  </tr>
                  <tr>
                    <td>Shepherd's pie</td>
                    <td>$8.00</td>
                    <td>1</td>
                    <td>16</td>
                    <td>$128.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /.row -->
          <div class="row">
            <div class="col-md-12">
              <label for="monday">Teusday</label>
              <table class="table table-stripped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Days</th>
                    <th>Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>The Great Feast Platter</td>
                    <td>$10.00</td>
                    <td>1</td>
                    <td>16</td>
                    <td>$150.00</td>
                  </tr>
                  <tr>
                    <td>Pumpkin Fizz</td>
                    <td>$2.00</td>
                    <td>2</td>
                    <td>16</td>
                    <td>$64.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /.row -->
          <div class="row">
            <div class="col-md-12">
              <label for="monday">Wednessday</label>
              <table class="table table-stripped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Days</th>
                    <th>Line Total</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /.row -->
          <div class="row">
            <div class="col-md-12">
              <label for="monday">Thursday</label>
              <table class="table table-stripped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Days</th>
                    <th>Line Total</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /.row -->
          <div class="row">
            <div class="col-md-12">
              <label for="monday">Friday</label>
              <table class="table table-stripped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Days</th>
                    <th>Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="col-md-4">Pumpkin Juice</td>
                    <td class="col-md-2">$1.00</td>
                    <td class="col-md-2">1</td>
                    <td class="col-md-2">16</td>
                    <td class="col-md-2">$16.00</td>
                  </tr>
                  <tr>
                    <td>Beef Sunday Roast</td>
                    <td>$15.00</td>
                    <td>1</td>
                    <td>16</td>
                    <td>$240.00</td>
                  </tr>
                  <tr>
                    <td>Chocolate Frog</td>
                    <td>$0.50</td>
                    <td>4</td>
                    <td>15</td>
                    <td>$30.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="row">
            <div class="col-md-5 col-md-offset-5">
              <span>Subtotal</span>
            </div>
            <div class="col-md-1 colmd1">
              <b>$660.00</b>
            </div>
            <div class="col-md-5 col-md-offset-5">
              Tax(6.875%)
               
            </div>
            <div class="col-md-1 colmd1">
               <b>$45.38</b>
            </div>
             <div class="col-md-10">
              <b>Total</b>
               
            </div>
            <div class="col-md-1 colmd1">
              <b>$705.38</b>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
