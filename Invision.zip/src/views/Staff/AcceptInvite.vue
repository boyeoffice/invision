<template>
	<div class="row">
		<div class="col-md-6">
			<div class="box box-default">
				<div class="box-header with-border">
					<h2 class="box-title">Accept Invitation</h2>
				</div>
				<div class="box-body">
					<form>
						<div class="form-group">
							<label>Email</label>
							<input type="text" class="form-control" disabled="disabled" value="prefilled-with-know-email@gmail.com">
						</div>
						<div class="form-group">
							<label>First Name</label>
							<input type="text" class="form-control">
						</div>
						<div class="form-group">
							<label>Last Name</label>
							<input type="text" class="form-control">
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="text" class="form-control">
						</div>
						<div class="form-group">
							<label>Confirm Password</label>
							<input type="text" class="form-control">
						</div>
					</form>
				</div>
				<div class="box-footer">
					<div class="row">
					<div class="col-md-6">
						<div class="form-group">
						<button class="btn btn-default">Cancel</button>
					</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
						<button class="btn btn-primary">Get Started</button>
					</div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>
</template>